// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)
//
// Lista de exercício sobre estruturas de dados homogêneas - Vetores.
//
// QUESTÃO 1:
// Implemente em vetores.cc as funções descritas em vetores.h.
//
// QUESTÃO 2:
// Escreva um programa em C++ que lê um conjunto de números de um arquivo e
// imprime na tela a média e o desvio padrão destes números.

#include "vetores/src/vetores.h"

int main() {
  return 0;  // TODO.
}
