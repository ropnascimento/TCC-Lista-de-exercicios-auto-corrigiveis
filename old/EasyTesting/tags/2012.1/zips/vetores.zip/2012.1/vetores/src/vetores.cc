// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)

#include "vetores/src/vetores.h"

float Media(float v[], int n) {
  return 0;  // TODO.
}

float Variancia(float v[], int n) {
  return 0;  // TODO.
}

float Maior(float v[], int n) {
  return 0;  // TODO.
}

float Menor(float v[], int n) {
  return 0;  // TODO.
}

float Modulo(float v[], int n) {
  return 0;  // TODO.
}

float ProdutoEscalar(float u[], float v[], int n) {
  return 0;  // TODO.
}

float CossenoVetores(float v[], float u[], int n) {
  return 0;  // TODO.
}

void MostraVetor(float v[], int n) {
  // TODO.
}
