// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)

#ifndef TRUNK_AGENDA_TEST_AGENDA_TEST_H_
#define TRUNK_AGENDA_TEST_AGENDA_TEST_H_

#include <cmath>
#include <sstream>
#include <string>

#include "gtest/gtest.h"
#include "agenda/src/agenda.h"

using std::string;
using std::stringstream;

namespace Teste {

TEST(Teste, Nenhum_teste_disponivel) {
}

}  // Fim do namespace vazio.

#endif  // TRUNK_AGENDA_TEST_AGENDA_TEST_H_
