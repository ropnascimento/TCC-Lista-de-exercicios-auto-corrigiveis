// Copyright 2012 Universidade Federal de Minas Gerais (UFMG)

#ifndef TRUNK_AGENDA_SRC_AGENDA_H_
#define TRUNK_AGENDA_SRC_AGENDA_H_

#include <string>

struct Contato {
    std::string nome;
    std::string telefone;
    std::string aniversario;
};

#endif  // TRUNK_AGENDA_SRC_AGENDA_H_
