// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)
//
// Lista de exercícios sobre algoritmos recursivos.
//
// QUESTÃO 1:
// Implemente em recursao.cc as funções descritas em recursao.h.
//
// QUESTÃO 2:
// Escreva um programa que (i) apresenta um menu com as funções que você
// programou na questão anterior e após o usuário escolher uma das funções
// (ii) lê o valor dos parâmetros e (iii) exibe o resultado da função.

#include "recursao/src/recursao.h"

int main() {
  return 0;  // TODO.
}

