// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)

#include "recursao/src/recursao.h"

int fat(int n) {
  return 0;  // TODO.
}

int pow(int k, int n) {
  return 0;  // TODO.
}

int mdc(int a, int b) {
  return 0;  // TODO.
}

int mdc3(int a, int b, int c) {
  return 0;  // TODO.
}

int mmc(int a, int b) {
  return 0;  // TODO.
}

int fib(int n) {
  return 0;  // TODO.
}

int resto(int a, int b) {
  return 0;  // TODO.
}

int div_(int a, int b) {
  return 0;  // TODO.
}

int dig(int n) {
  return 0;  // TODO.
}
