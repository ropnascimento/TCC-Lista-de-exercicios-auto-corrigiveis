// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)

#include "complexo_polar/src/complexo.h"

Complexo::Complexo() {
  // TODO.
}

Complexo::Complexo(double a) {
  // TODO.
}

Complexo::Complexo(double a, double b) {
  // TODO.
}

double Complexo::real() {
  return 0;  // TODO.
}

double Complexo::imag() {
  return 0;  // TODO.
}

bool Complexo::operator==(Complexo x) {
  return false;  // TODO.
}

void Complexo::operator=(Complexo x) {
  // TODO.
}

double Complexo::modulo() {
  return 0;  // TODO.
}

Complexo Complexo::conjugado() {
  Complexo c;  // TODO.
  return c;
}

Complexo Complexo::simetrico() {
  Complexo c;  // TODO.
  return c;
}

Complexo Complexo::inverso() {
  Complexo i;  // TODO.
  return i;
}

Complexo Complexo::operator+(Complexo y) {
  Complexo s;  // TODO.
  return s;
}

Complexo Complexo::operator-(Complexo y) {
  Complexo s;  // TODO.
  return s;
}

Complexo Complexo::operator*(Complexo y) {
  Complexo p;  // TODO.
  return p;
}

Complexo Complexo::operator/(Complexo y) {
  Complexo q;  // TODO.
  return q;
}
