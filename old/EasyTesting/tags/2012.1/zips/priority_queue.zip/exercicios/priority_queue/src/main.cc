// Copyright 2011 Universidade Federal de Minas Gerais (UFMG)
//
// Lista sobre Filas de Prioridade.
//
// Questão 1.
// Implemente em priority_queue.h e priority_queue.cc o TAD priority_queue,
// utilizando árvores binárias de busca.
//
// Questão 2.
// Implemente uma função "void PriorityQueueSort(int n, float v[])" que ordena
// os elementos de um vetor utilizando uma priority_queue.
//
// Questão 3.
// Escreva um programa para testar a função da questão anterior.

#include "priority_queue/src/priority_queue.h"

int main() {
  return 0;  // TODO.
}
