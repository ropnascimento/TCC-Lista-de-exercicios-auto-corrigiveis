// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)

#include "funcoes/src/funcoes.h"

float media(float a, float b, float c) {
  return 0;  // TODO.
}

float media_ponderada(float a, float b, float c) {
  return 0;  // TODO.
}

float perimetro(float r) {
  return 0;  // TODO.
}

float area_circulo(float r) {
  return 0;  // TODO.
}

float area_triangulo(float b, float c) {
  return 0;  // TODO.
}

float area_caixa(float a, float b, float c) {
  return 0;  // TODO.
}

float volume_caixa(float a, float b, float c) {
  return 0;  // TODO.
}

float area_cilindro(float r, float h) {
  return 0;  // TODO.
}

float volume_cilindro(float r, float h) {
  return 0;  // TODO.
}

float hipotenusa(float b, float c) {
  return 0;  // TODO.
}
