// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)
//
// Lista de exercícios sobre algoritmos iterativos.
//
// QUESTÃO 1:
// Implemente em iteracao.cc as funções descritas em iteracao.h.
//
// QUESTÃO 2:
// Escreva um programa que (i) apresenta um menu com as funções que você
// programou na questão anterior e após o usuário escolher uma das funções
// (ii) lê o valor dos parâmetros e (iii) exibe o resultado da função.

#include "iteracao/src/iteracao.h"

int main() {
  return 0;  // TODO.
}


