// Copyright 2010 Universidade Federal de Minas Gerais (UFMG)
//
// Lista de exercícios sobre Tipos Abstratos de Dados.
// Aplicação: Números Complexos - Coordenadas Euclidianas.
//
// QUESTÃO 1:
// Implemente em complexo.cc as funções descritas em complexo.h.
//
// QUESTÃO 2:
// Escreva um programa que simula uma calculadora de números complexos.
// Ele deve apresentar um menu com as operações de soma, subtração,
// multiplicação, divisão, módulo e conjugado. Após o usuário escolher uma das
// funções, o programa deve ler o valor dos parâmetros e em seguida exibir o
// resultado da função.
//
// QUESTÃO 3:
// Escreva uma função "void CalcularRaizes(float a, float b, float c,
// Complexo* r1, Complexo* r2)" que recebe os coeficientes
// de uma equação de segundo grau "a.x^2 + b.x + c = 0" e retorna por r1 e r2
// as raízes (possivelmente complexas) desta equação.
//
// QUESTÃO 4:
// Escreva um programa que lê do teclado os coeficientes reais de uma equação de
// segundo grau e imprime na tela as raízes (possivelmente complexas) desta
// equação.

#include "complexo_euclidiano/src/complexo.h"

int main() {
  return 0;  // TODO.
}
