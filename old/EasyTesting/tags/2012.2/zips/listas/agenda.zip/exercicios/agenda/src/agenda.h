// Copyright 2012 Universidade Federal de Minas Gerais (UFMG)

#ifndef TRUNK_AGENDA_SRC_AGENDA_H_
#define TRUNK_AGENDA_SRC_AGENDA_H_

#include <string>

struct Contato {
  // TODO.
};

#endif  // TRUNK_AGENDA_SRC_AGENDA_H_
