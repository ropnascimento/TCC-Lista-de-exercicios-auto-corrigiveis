// Copyright 2014 Universidade Federal de Minas Gerais (UFMG)
//
// Lista de exercícios sobre listas encadeadas - pilha.
//
// Questão 1.
// Implemente em stack.h e stack.cc o TAD stack, utilizando listas encadeadas.
//
// Questão 2.
// Escreva uma função "void ImprimirInfixado(stack* exp)" que recebe
// como parâmetro uma pilha 'exp' que representa uma expressão em notação
// pré-fixada e remove os operadores e operandos de 'exp', imprimindo-os em
// notação infixada totalmente parametrizada.
// Por exemplo: para para a pilha contendo a expressão "- / + 4 * 3 4 2 1",
// A função deve imprimir "( ( ( 4 + ( 3 * 4 ) ) / 2 ) - 1 )".
//
// Questão 3.
// Escreva um programa que (i) lê de um arquivo uma expressão em notação
// pré-fixada, (ii) imprime na tela a mesma expressão em notação infixada
// totalmente parametrizada.
// Por exemplo: para o arquivo contendo a expressão "- / + 4 * 3 4 2 1",
// O programa deve imprimir "( ( ( 4 + ( 3 * 4 ) ) / 2 ) - 1 )".

#include "stack_with_array/src/stack.h"

int main() {
  return 0;  // TODO.
}
